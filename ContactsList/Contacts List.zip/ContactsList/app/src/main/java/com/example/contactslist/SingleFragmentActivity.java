package com.example.contactslist;

import androidx.appcompat.app.AppCompatActivity;

public abstract class SingleFragmentActivity extends AppCompatActivity {
      protected abstract 
}
