package com.example.contactslist;

public class Contact {
    public void setTitle(String s) {
    }

    public void setSolved(boolean b) {
    }

    public Object getID() {
    }
}
