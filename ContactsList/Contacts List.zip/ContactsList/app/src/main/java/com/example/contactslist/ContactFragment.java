package com.example.contactslist;

import androidx.fragment.app.Fragment;

public class ContactFragment extends Fragment {
}
