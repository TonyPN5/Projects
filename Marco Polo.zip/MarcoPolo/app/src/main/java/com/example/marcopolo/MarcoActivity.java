package com.example.marcopolo;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Toast;
import android.widget.Toolbar;

import android.os.Bundle;

public class MarcoActivity extends AppCompatActivity {
    private Toast backtoast;
    private boolean mOppositeP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marco2);
    }
    @Override
    public void onBackPressed() {
        mOppositeP = true;
        if(mOppositeP) {
            if(backtoast!=null&&backtoast.getView().getWindowToken()!=null) {
                finish();
            } else {
                backtoast = Toast.makeText(this, "Polo!", Toast.LENGTH_SHORT);
                backtoast.show();
            }
        }
        else {
            //other stuff...
            super.onBackPressed();
        }
    }
}