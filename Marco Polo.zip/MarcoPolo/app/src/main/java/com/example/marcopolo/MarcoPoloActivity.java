package com.example.marcopolo;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Toolbar;


public class MarcoPoloActivity extends AppCompatActivity
{
    private Button mMarcoButton;
    private Button mPoloButton;
    private boolean mOppositeP;
    private Toast backtoast;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMarcoButton = (Button)findViewById(R.id.Marco_button);
        mPoloButton = (Button)findViewById(R.id.Polo_button);
        mMarcoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOppositeP = true;
                Intent intent = new Intent(MarcoPoloActivity.this, MarcoActivity.class);
                startActivity(intent);
            }

        });
       mPoloButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(MarcoPoloActivity.this,
                           // R.string.Polo_toast,
                           // Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MarcoPoloActivity.this, PoloActivity.class);
                    startActivity(intent);
                }
        });
    };

}
