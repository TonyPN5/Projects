package com.example.marcopolo;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MarcoPoloActivity extends AppCompatActivity
{
    private Button mMarcoButton;
    private Button mPoloButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMarcoButton = (Button)findViewById(R.id.Marco_button);
        mPoloButton = (Button)findViewById(R.id.Polo_button);
        mMarcoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MarcoPoloActivity.this,
                        R.string.Marco_toast,
                        Toast.LENGTH_SHORT).show();
            }
        });
       mPoloButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MarcoPoloActivity.this,
                            R.string.Polo_toast,
                            Toast.LENGTH_SHORT).show();
                }
        });
    };
}
